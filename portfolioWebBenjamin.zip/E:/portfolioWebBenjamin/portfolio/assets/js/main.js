const hamburger=document.getElementById('hamburger');
const navMenu=document.getElementById('nav-menu');
if(hamburger){hamburger.addEventListener('click',()=>navMenu.classList.toggle('show'));}
const toggleBtn = document.getElementById('light-toggle');
if (toggleBtn) {
  toggleBtn.addEventListener('click', () => {
    document.documentElement.classList.toggle('light-mode');
    localStorage.setItem('theme', document.documentElement.classList.contains('light-mode') ? 'light' : 'dark');
  });

  // Verifica y aplica el tema guardado al cargar
  const savedTheme = localStorage.getItem('theme');
  if (savedTheme === 'light') {
    document.documentElement.classList.add('light-mode');
  }
}


hamburger.addEventListener('click', () => {
  navMenu.classList.toggle('show');
});

